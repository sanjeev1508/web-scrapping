import scrapy
import firebase_admin
from firebase_admin import credentials, db
import logging
import time
import random

# Initialize Firebase Admin SDK
cred = credentials.Certificate("F:\\myproject1\\myproject1\\config\\serviceAccountKey.json")  # Provide the path to your Firebase Admin SDK service account key
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://sample-project-e82ad-default-rtdb.firebaseio.com/'  # Use your Firebase URL
})

class MySpider(scrapy.Spider):
    name = "my_spider"

    custom_settings = {
        'DOWNLOAD_DELAY': 2,  # Add delay between requests
        'CONCURRENT_REQUESTS_PER_DOMAIN': 1,  # Limit concurrent requests
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36',  # Set a common user-agent
        'ROBOTSTXT_OBEY': False  # Optional: Set to False if you want to ignore robots.txt
    }

    def start_requests(self):
        # Load URLs from Firebase
        urls = self.load_urls_from_firebase()
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def load_urls_from_firebase(self):
        # Fetch URLs stored in Firebase (assuming it's stored under '/products/amazon')
        result = db.reference('/products/amazon').get()
        if result:
            urls = [product.get('url') for product in result.values() if product.get('url')]
            return urls
        else:
            logging.error("No URLs found in Firebase.")
            return []

    def parse(self, response):
        if response.status != 200:
            logging.error(f"Failed to retrieve data for {response.url}. Status code: {response.status}")
            return
        
        # Corrected selector for price
        price = response.css('#priceblock_ourprice::text').get() or response.css('.a-price .a-price-whole::text').get()
        price = price.strip() if price else "Price not found"
        
        # Print product details to the terminal
        print(f"Price: {price}")

        # Update Firebase with the scraped data
        product_data = {
            'price': price,
        }

        # Store the data back into Firebase
        self.update_firebase(response.url, product_data)

        # Random delay to mimic human behavior
        time.sleep(random.uniform(1, 3))

    def update_firebase(self, url, product_data):
        # Find the product entry in Firebase using the URL and update the data
        products = db.reference('/products/amazon').get()
        if products:
            for key, product in products.items():
                if product.get('url') == url:
                    # Update the product data in Firebase
                    db.reference(f'/products/amazon/{key}/price').set(product_data['price'])
                    logging.info(f"Updated product in Firebase: {product_data}")
                    break
        else:
            logging.error("Product URL not found in Firebase.")
