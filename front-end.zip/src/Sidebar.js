import React from 'react';
import './Sidebar.css';
import userPic from './assets/logo.jpg'; // Import the image from the assets folder

const Sidebar = ({ onSelectCategory }) => {
    const handleHomeClick = () => {
        window.location.reload(); // Reload the page when clicked
    };

    const handleAppleProductsClick = () => {
        onSelectCategory('Apple Products');
    };

    return (
        <div className="sidebar">
            <div className="profile">
                <img src={userPic} alt="User Picture" /> {/* Use the imported image */}
            </div>
            
            <div className="menu">
                <div className="menu-item" onClick={handleHomeClick}>
                    <i className="fas fa-home"></i><span>Home</span>``
                </div>
                <div className="menu-item" onClick={handleAppleProductsClick}>
                    <i className="fab fa-apple"></i><span>Apple Products</span>
                </div>
                <div className="menu-item"><i className="fas fa-comments"></i><span>Feedback</span></div>
                <div className="menu-item"><i className="fas fa-cog"></i><span>Settings</span></div>
                <div className="menu-item"><i className="fas fa-info"></i><span>About</span></div>
            </div>
        </div>
    );
};

export default Sidebar;
