// firebase.js
import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: 'AIzaSyAj84fE__PB0ufBtJmngrdkAR9EZXwrTSM',
  authDomain: 'sample-project-e82ad.firebaseapp.com',
  databaseURL: 'https://sample-project-e82ad-default-rtdb.firebaseio.com',
  projectId: 'sample-project-e82ad',
  storageBucket: 'sample-project-e82ad.appspot.com',
  messagingSenderId: '924029651544',
  appId: '1:924029651544:web:031c13bd222e0ef1e8582d',
  measurementId: 'G-8Q8PZZ3ZJ6',
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

export { database };
