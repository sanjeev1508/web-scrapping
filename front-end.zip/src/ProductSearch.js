import React, { useEffect, useState } from 'react';
import { db } from './firebase';

const ProductSearch = () => {
  const [products, setProducts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    const fetchProducts = async () => {
      const snapshot = await db.ref('products').once('value');
      const data = snapshot.val();
      const productList = [];

      for (const platform in data) {
        for (const productId in data[platform]) {
          const product = data[platform][productId];
          productList.push({
            id: productId,
            name: product['product name'],
            color: product['product color'],
            imgUrl: product['product img url'],
            price: product['product price'],
            storage: product['product storage']
          });
        }
      }
      setProducts(productList);
    };

    fetchProducts();
  }, []);

  const handleSearch = (event) => {
    setSearchQuery(event.target.value);
    const foundProduct = products.find(product => 
      product.name.toLowerCase().includes(event.target.value.toLowerCase())
    );
    if (foundProduct) {
      setSelectedProduct(foundProduct);
    } else {
      setSelectedProduct(null);
    }
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Search for a product..."
        value={searchQuery}
        onChange={handleSearch}
      />
      {selectedProduct && (
        <div>
          <h2>{selectedProduct.name}</h2>
          <p>Color: {selectedProduct.color}</p>
          <p>Storage: {selectedProduct.storage}</p>
          <p>Price: {selectedProduct.price}</p>
          <img src={selectedProduct.imgUrl} alt={selectedProduct.name} />
        </div>
      )}
    </div>
  );
};

export default ProductSearch;
