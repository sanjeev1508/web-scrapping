import React, { useEffect, useState } from 'react';
import './App.css';
import Sidebar from './Sidebar';
import { ref, onValue } from 'firebase/database';
import { database } from './firebase'; // Ensure your firebase.js is correctly configured

function App() {
  const [products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);

  useEffect(() => {
    const fetchProducts = () => {
      const amazonRef = ref(database, 'products/amazon');
      const flipkartRef = ref(database, 'products/flipkart');

      // Clear previous products and fetch Amazon products
      onValue(amazonRef, (snapshot) => {
        let newProducts = []; // Temporary array for Amazon products
        if (snapshot.exists()) {
          const data = snapshot.val();
          newProducts = Object.entries(data).map(([id, product]) => ({
            id: `amazon-${id}`,
            ...product,
            platform: 'Amazon',
          }));
        } else {
          console.log('No Amazon products found in the database.');
        }

        // Fetch Flipkart products
        onValue(flipkartRef, (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.val();
            const flipkartProducts = Object.entries(data).map(([id, product]) => ({
              id: `flipkart-${id}`,
              ...product,
              platform: 'Flipkart',
            }));
            setProducts([...newProducts, ...flipkartProducts]); // Combine products once both are fetched
          } else {
            console.log('No Flipkart products found in the database.');
            setProducts(newProducts); // Set Amazon products if Flipkart has none
          }
        });
      });
    };

    // Only fetch if the selected category is 'Apple Products'
    if (selectedCategory === 'Apple Products') {
      fetchProducts();
    }
  }, [selectedCategory]);

  const handleCardClick = (url) => {
    if (url) {
      window.open(url, '_blank'); // Opens in a new tab
    } else {
      console.log('URL is missing or incorrect');
    }
  };

  const handleCategorySelection = (category) => {
    setSelectedCategory(category);
  };

  return (
    <div className="app-container">
      <Sidebar onSelectCategory={handleCategorySelection} />
      <div className="content">
        <header>
          <h1>Explore Using SideBar !</h1>
        </header>

        <div className="product-list">
          {products.map((product) => (
            <div
              key={product.id}
              className="product-card"
              onClick={() => handleCardClick(product.url)}
            >
              <img src={product.img_url} alt={product.name} />
              <div className="product-info">
                <h2>{product.name}</h2>
                <p>Price: {product.price}</p>
                <p>Platform: {product.platform}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;
