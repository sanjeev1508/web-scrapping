import React from 'react';
import './Sidebar.css'; // Make sure to create this CSS file

const Sidebar = () => {
    return (
        <div className="sidebar">
            <div className="profile">
                <img src="background.jpg" alt="Profile" />
            </div>
            <div className="menu">
                <div className="menu-item"><i className="fa fa-home"></i><span>Home</span></div>
                <div className="menu-item"><i className="fab fa-apple" aria-hidden="true"></i><span>Apple products</span></div>
                <div className="menu-item"><i className="fa fa-comments" aria-hidden="true"></i><span>Feedback</span></div>
                <div className="menu-item"><i className="fa fa-cog"></i><span>Settings</span></div>
                <div className="menu-item"><i className="fa fa-info" aria-hidden="true"></i><span>About</span></div>
            </div>
        </div>
    );
};

export default Sidebar;
