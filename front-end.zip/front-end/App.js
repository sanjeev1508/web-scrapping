import React from 'react';
import Sidebar from './Sidebar'; // Adjust the path if necessary

const App = () => {
    return (
        <div>
            <Sidebar />
            {/* Other components can go here */}
        </div>
    );
};

export default App;
