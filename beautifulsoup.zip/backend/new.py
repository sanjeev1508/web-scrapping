import requests
from bs4 import BeautifulSoup
import time
import firebase_admin
from firebase_admin import credentials, db

# Firebase Setup
cred = credentials.Certificate("F:/backend/serviceAccountKey.json")  # Adjust the path accordingly
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://sample-project-e82ad-default-rtdb.firebaseio.com/'
})

# Firebase database reference to products
ref = db.reference('/products/amazon')
products = ref.get()


for product_key, product in products.items():
    url = product.get('url')
    if url:
        print(f"Product URL: {url}")
    else:
        print(f"No URL found for product {product_key}")

# Custom headers to mimic a browser request
custom_headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9"
}

# Function to fetch the product price from a given URL
def fetch_price(url):
    try:
        response = requests.get(url, headers=custom_headers)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'lxml')

            # Try different selectors to find the price
            price_element = soup.select_one('.a-price-whole, .a-price .a-offscreen')
            price_fraction = soup.select_one('.a-price-fraction')

            if price_element:
                # Clean up the price string
                price = price_element.text.strip()
                if price_fraction:
                    price += price_fraction.text.strip()  # Append fraction part if available
                price = price.replace(',', '')  # Remove commas from price
                return price
            else:
                print(f"Price not found for URL: {url}")
                return None
        else:
            print(f"Failed to retrieve the page. Status code: {response.status_code}")
            return None
    except Exception as e:
        print(f"Error fetching the page: {e}")
        return None

# Function to update prices for all products in Firebase
def update_prices():
    products = ref.get()  # Retrieve all products from Firebase

    if products:
        for product_key, product_data in products.items():
            product_url = product_data.get('url')
            if product_url:
                print(f"Fetching price for {product_data.get('name', 'Unknown Product')} from {product_url}")
                new_price = fetch_price(product_url)  # Fetch the new price

                if new_price:
                    # Update the product price in Firebase
                    ref.child(product_key).update({"price": new_price})
                    print(f"Updated price for {product_data.get('name', 'Unknown Product')}: ₹{new_price}")
            else:
                print(f"No URL found for product {product_key}")
    else:
        print("No products found in Firebase.")

# Retry mechanism
for attempt in range(3):
    update_prices()
    time.sleep(2)  # Delay between retries
