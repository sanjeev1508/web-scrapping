import requests
from bs4 import BeautifulSoup
import firebase_admin
from firebase_admin import credentials, db

# Path to your Firebase service account key
cred = credentials.Certificate("F:/backend/serviceAccountKey.json")  # Adjust the path accordingly

# Initialize the Firebase app with a service account
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://sample-project-e82ad-default-rtdb.firebaseio.com/'
})

def scrape_product_details(product_url):
    """
    Scrape the product details from the provided Amazon product URL.
    
    Args:
        product_url (str): The URL of the Amazon product to scrape.
    
    Returns:
        dict: A dictionary containing the product's price and the original product URL.
        None: If scraping fails or if elements are not found.
    """
    try:
        # Set headers to mimic a browser request
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://www.amazon.in/"
        }
        
        # Send an HTTP GET request to the product URL
        response = requests.get(product_url, headers=headers)
        response.raise_for_status()

        # Parse the HTML content using BeautifulSoup
        soup = BeautifulSoup(response.text, 'html.parser')

        # Extract product price
        product_price = soup.find('span', {'class': 'a-price-whole'})
        product_price = product_price.text.strip().replace(",", "") if product_price else None

        # Return the scraped product details
        return {
            'price': product_price,
            'url': product_url  # Include the product URL for future reference
        }

    except Exception as e:
        print(f"Error fetching product details from {product_url}: {e}")
        return None

def update_product_price_in_firebase(product_id, platform, price):
    """
    Update the product price in the Firebase database without altering other fields.
    
    Args:
        product_id (str): The unique ID of the product in the Firebase database.
        platform (str): The platform (e.g., 'amazon') under which the product is stored in the database.
        price (str): The new price to be updated in Firebase.
    """
    try:
        # Reference to the specific product entry in Firebase
        ref = db.reference(f'products/{platform}/{product_id}')
        # Update only the price field
        ref.update({'price': price})  
        print(f"Successfully updated price for {product_id} in {platform} to: {price}")

    except Exception as e:
        print(f"Error updating price for {product_id} in Firebase: {e}")

def update_all_products():
    """
    Fetch all Amazon products from Firebase, scrape their prices, and update them in the database.
    """
    try:
        # Reference to all Amazon products in the Firebase database
        ref = db.reference('products/amazon')
        products = ref.get()

        # Iterate through each product and update its price
        if products:
            for product_id, product in products.items():
                product_url = product.get('url')
                if product_url:
                    print(f"Scraping price for product {product_id} from {product_url}...")
                    product_details = scrape_product_details(product_url)
                    if product_details and product_details['price'] is not None:
                        update_product_price_in_firebase(product_id, 'amazon', product_details['price'])
                    else:
                        print(f"Could not retrieve price for product {product_id}")
                else:
                    print(f"No URL found for product {product_id}")

    except Exception as e:
        print(f"Error fetching products from Firebase: {e}")

if __name__ == "__main__":
    update_all_products()
